﻿local AL = _G.AtlasLoot.GetLocales("esMX")

if not AL then return end

-- These localization strings are translated on Curseforge: https://www.curseforge.com/wow/addons/atlaslootclassic/localization
-- Options
